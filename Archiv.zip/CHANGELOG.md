# CHANGELOG.md

## [2.0.0] - 2025-02-04

- Upgrade to Tailwind 4
- Update other dependencies

## [1.3.2] - 2024-10-21

- Update dependencies
- Fix issue with Transition component

## [1.3.0] - 2024-07-05

- Update dependencies

## [1.2.0] - 2023-12-07

- Update Next.js to 14

## [1.1.1] - 2023-11-12

Pricing slider integration

## [1.1.0] - 2023-10-27

Design improvements

## [1.0.0] - 2023-10-12

First release
